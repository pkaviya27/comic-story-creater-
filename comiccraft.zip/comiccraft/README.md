# ComicCraft - AI Comic Story Creator using Gemini Models

A FastAPI web app that turns a story prompt into a full illustrated comic:
Gemini Flash builds a 5-panel outline, Gemini Pro writes the narration and
dialogue, Stable Diffusion (via Hugging Face Diffusers) illustrates each
panel, and the result is exported as a downloadable PDF.

## Project structure

```
comiccraft/
├── app/
│   ├── main.py            # FastAPI app entrypoint
│   ├── routes.py          # All routes (/, /generate, /generate-comic/json, /export-success, /test-image)
│   ├── gemini_flash.py    # generate_outline() – 5-panel comic outline
│   ├── gemini_pro.py      # generate_story() – narration & dialogue
│   ├── image_generator.py # generate_image() – Stable Diffusion illustrations
│   ├── layout_builder.py  # build_comic_layout() – combines images + text
│   └── exporters.py       # save_pdf() – compiles comic into a PDF
├── templates/
│   ├── index.html          # story input form
│   ├── comic_preview.html  # panel-by-panel preview + download button
│   └── export_success.html # confirmation page
├── static/
│   ├── panels/   # generated panel images land here
│   ├── exports/  # generated PDFs land here
│   └── fonts/    # optional Unicode TTF font for PDF export
├── requirements.txt
└── .env.example
```

## 1. Set up the environment

```bash
cd comiccraft
python -m venv comiccraft-env

# Windows
comiccraft-env\Scripts\activate
# macOS/Linux
source comiccraft-env/bin/activate

pip install -r requirements.txt
```

> Stable Diffusion downloads a multi-GB model on first run and runs much
> faster with a CUDA-capable GPU. On CPU-only machines it will still work,
> just slowly.

## 2. Add your API keys

Copy `.env.example` to `.env` and fill in your keys:

```
GEMINI_API_KEY=your_gemini_api_key_here
HF_API_KEY=your_huggingface_api_key_here
```

- Get a Gemini key from Google AI Studio.
- Get a Hugging Face token from huggingface.co/settings/tokens, and accept
  the `runwayml/stable-diffusion-v1-5` model license on its model page
  before your token can download it.

## 3. Run the server

```bash
uvicorn app.main:app --reload
```

- App: http://127.0.0.1:8000
- Interactive API docs: http://127.0.0.1:8000/docs

## 4. Try it

1. Open the homepage, fill in a story prompt, character name, setting,
   tone, and art style, and submit.
2. Review the generated panel-by-panel comic on the preview page.
3. Click **Download Your Comic as PDF** to export it to `static/exports/`.

## API endpoints

| Route                    | Method | Purpose                                              |
|---------------------------|--------|-------------------------------------------------------|
| `/`                        | GET    | Homepage / input form                                 |
| `/generate`                | POST   | Form-based comic generation → renders preview page    |
| `/generate-comic/json`     | POST   | JSON-based comic generation → returns JSON            |
| `/export-success`          | GET    | Export confirmation page                               |
| `/test-image`              | GET    | Generate a single test image from a prompt             |

## Notes / things you may want to extend

- **PDF Unicode support**: `exporters.py` uses the built-in Helvetica font
  by default (Latin-1 only). Drop a `DejaVuSans.ttf` file into
  `static/fonts/` to get full Unicode support automatically.
- **No user accounts yet**: this version generates one comic per request
  with no persistence — a natural next step is adding user profiles and a
  comic library.
- **Cost/latency**: each `/generate` call makes 2 Gemini calls + 5 Stable
  Diffusion image generations, so expect it to take a while, especially on
  CPU.

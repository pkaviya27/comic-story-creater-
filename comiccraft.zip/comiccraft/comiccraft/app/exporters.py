"""
Compiles the finished comic (images + narration) into a downloadable PDF.
"""

import os
from datetime import datetime
from fpdf import FPDF

from app.story_formatter import normalize_typography

EXPORT_FOLDER = "static/exports"
# Optional: drop a Unicode TTF font (e.g. DejaVuSans.ttf) here to support
# non-Latin characters / smart quotes in AI-generated text.
FONT_PATH = "static/fonts/DejaVuSans.ttf"

os.makedirs(EXPORT_FOLDER, exist_ok=True)


class PDF(FPDF):
    pass


def _configure_font(pdf: "PDF"):
    """Uses a Unicode TTF font if available, otherwise falls back to a core PDF font."""
    if os.path.exists(FONT_PATH):
        pdf.add_font("DejaVu", "", FONT_PATH, uni=True)
        pdf.add_font("DejaVu", "B", FONT_PATH, uni=True)
        pdf.add_font("DejaVu", "I", FONT_PATH, uni=True)
        pdf.set_font("DejaVu", "", 12)
        return "DejaVu"
    else:
        # Core fonts don't need a font file but only support Latin-1.
        pdf.set_font("Helvetica", "", 12)
        return "Helvetica"


def _safe(text: str, font_name: str) -> str:
    """Normalizes smart-quote/typographic characters so Helvetica (Latin-1
    only) never has to fall back to '?' placeholders."""
    text = normalize_typography(text)
    if font_name == "Helvetica":
        text = text.encode("latin-1", "replace").decode("latin-1")
    return text


def save_pdf(layout):
    """
    Compiles the full comic into a multi-page PDF file.

    Args:
        layout (list[dict]): Output of build_comic_layout(), one dict per panel.

    Returns:
        str: Path to the saved PDF file.
    """
    pdf = PDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    font_name = _configure_font(pdf)

    for panel in layout:
        image_path = panel["image_path"]
        blocks = panel.get("blocks") or []

        pdf.add_page()

        # Panel title
        pdf.set_font(font_name, "B", 14)
        pdf.cell(0, 10, _safe(f"Panel {panel['panel']}: {panel.get('title', '')}", font_name), ln=True, align="C")
        pdf.set_font(font_name, "", 12)

        # Image placement
        y_image = 30
        image_height = 100
        spacing_after_image = 15

        if os.path.exists(image_path):
            pdf.image(image_path, x=10, y=y_image, w=pdf.w - 20, h=image_height)
        else:
            pdf.set_y(y_image)
            pdf.multi_cell(0, 10, f"Image missing: {image_path}")

        # Text placement below image, styled per block type
        pdf.set_y(y_image + image_height + spacing_after_image)

        if blocks:
            for block in blocks:
                btype = block.get("type")
                text = block.get("text", "")

                if btype == "caption":
                    pdf.set_font(font_name, "I", 11)
                    pdf.multi_cell(0, 7, _safe(text, font_name))
                elif btype == "scene":
                    pdf.set_font(font_name, "I", 11)
                    pdf.multi_cell(0, 7, _safe(text, font_name))
                elif btype == "sfx":
                    pdf.set_font(font_name, "B", 12)
                    pdf.multi_cell(0, 7, _safe(text.upper(), font_name), align="C")
                elif btype == "dialogue":
                    speaker = block.get("speaker", "")
                    pdf.set_font(font_name, "B", 11)
                    pdf.write(7, _safe(f"{speaker}: ", font_name))
                    pdf.set_font(font_name, "", 11)
                    pdf.multi_cell(0, 7, _safe(text, font_name))
                else:
                    pdf.set_font(font_name, "", 11)
                    pdf.multi_cell(0, 7, _safe(text, font_name))

                pdf.ln(1)
        else:
            # Fallback: no structured blocks available, print raw text.
            pdf.set_font(font_name, "", 11)
            pdf.multi_cell(0, 7, _safe(panel.get("text", ""), font_name))

    # Save with timestamp
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filename = f"comic_{timestamp}.pdf"
    pdf_path = os.path.join(EXPORT_FOLDER, filename)
    pdf.output(pdf_path)

    return pdf_path

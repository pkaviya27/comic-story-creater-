"""
Expands a panel outline into full comic narration and dialogue using Gemini Pro.
"""

import os
import google.generativeai as genai

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("models/gemini-3.8-flash")


def generate_story(outline: list) -> str:
    """
    Generates a detailed comic story with narration and character dialogue
    from a list of comic panel outlines using Gemini 1.5 Pro.

    Args:
        outline (list): A list of dicts (or strings) representing each comic panel's idea.

    Returns:
        str: The generated comic story text, or an error message.
    """
    # Format the panel outline as a numbered list for clarity
    formatted_lines = []
    for i, item in enumerate(outline):
        if isinstance(item, dict):
            label = item.get("title", f"Panel {i + 1}")
            desc = item.get("scene_description", "")
            formatted_lines.append(f"{i + 1}. {label} - {desc}")
        else:
            formatted_lines.append(f"{i + 1}. {item}")
    formatted_outline = "\n".join(formatted_lines)

    prompt = f"""
You're a comic book writer.

Given the following panel breakdown, write a comic-style story with engaging narration and character dialogues for each panel.

Panel Outline:
{formatted_outline}

Guidelines:
- Use a fun and engaging tone, like an actual comic book.
- Include narration and clearly marked character lines.
- Keep each panel self-contained but part of a cohesive story.
- Start each panel's section with "**Panel <number>: <title>**" so it can be split programmatically.
"""

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error generating story: {str(e)}"

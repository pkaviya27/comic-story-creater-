"""
Parses the raw narration text returned by Gemini into structured "blocks"
(caption, sound effect, scene description, dialogue, narration) so both the
web preview and the PDF export can render them with proper comic styling
instead of dumping raw bracket-tagged text.
"""

import re

CAPTION_RE = re.compile(r"^\[CAPTION:\s*(.*?)\]$", re.IGNORECASE)
SFX_RE = re.compile(r"^\[SFX:\s*(.*?)\]$", re.IGNORECASE)
SCENE_RE = re.compile(r"^\[SCENE DESCRIPTION:\s*(.*?)\]$", re.IGNORECASE)
# "SPEAKER: dialogue text" — speaker names are short and mostly uppercase.
DIALOGUE_RE = re.compile(r"^([A-Z][A-Z0-9 _'\-]{1,30}):\s*(.+)$")


def normalize_typography(text: str) -> str:
    """
    Converts 'smart' typographic characters (curly quotes, em dashes, etc.)
    into plain ASCII equivalents so they render correctly even with fonts
    that only support Latin-1 (e.g. the PDF's default core font).
    """
    replacements = {
        "\u2018": "'", "\u2019": "'",   # ' '
        "\u201c": '"', "\u201d": '"',   # " "
        "\u2013": "-", "\u2014": "-",   # – —
        "\u2026": "...",                 # …
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    return text


def parse_story_blocks(raw_text: str) -> list:
    """
    Breaks a panel's raw story text into a list of typed blocks.

    Returns:
        list[dict]: each dict has "type" (one of "caption", "sfx", "scene",
        "dialogue", "narration") and "text". "dialogue" blocks also have
        a "speaker" key.
    """
    text = normalize_typography(raw_text)
    text = text.replace("***", "").strip()

    blocks = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        m = CAPTION_RE.match(line)
        if m:
            blocks.append({"type": "caption", "text": m.group(1).strip()})
            continue

        m = SFX_RE.match(line)
        if m:
            blocks.append({"type": "sfx", "text": m.group(1).strip()})
            continue

        m = SCENE_RE.match(line)
        if m:
            blocks.append({"type": "scene", "text": m.group(1).strip()})
            continue

        m = DIALOGUE_RE.match(line)
        if m:
            blocks.append({
                "type": "dialogue",
                "speaker": m.group(1).strip(),
                "text": m.group(2).strip(),
            })
            continue

        blocks.append({"type": "narration", "text": line})

    return blocks

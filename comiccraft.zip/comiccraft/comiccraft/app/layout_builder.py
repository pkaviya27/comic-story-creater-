"""
Organizes generated images and the full comic story text into a structured
panel-by-panel layout ready for the preview page / PDF exporter.
"""

from app.story_formatter import parse_story_blocks


def build_comic_layout(image_paths, full_story, outline):
    """
    Combines images, story text, and outline metadata into one layout list.

    Args:
        image_paths (list[str]): File paths of the generated panel images, in order.
        full_story (str): The full narration/dialogue text returned by Gemini Pro,
            expected to contain "**Panel N" markers separating each panel.
        outline (list[dict]): The original panel outline from Gemini Flash.

    Returns:
        list[dict]: One dict per panel with keys "panel", "title", "image_path",
            "text", "blocks", and "scene_description".
    """
    # Split the full story into individual panel segments
    story_panels = full_story.split("**Panel")
    story_panels = [f"**Panel{panel}" for panel in story_panels if panel.strip()]

    # If the model didn't use the "**Panel" marker, fall back to splitting on
    # the "***" separator it sometimes uses between panels instead.
    if len(story_panels) < len(outline) and "***" in full_story:
        story_panels = [p for p in full_story.split("***") if p.strip()]

    # Build layout panel by panel
    layout = []
    for idx, (image, text, panel_info) in enumerate(
        zip(image_paths, story_panels, outline), start=1
    ):
        lines = text.strip().splitlines()
        # Drop a leading "**Panel N: Title**"-style marker line if present
        if lines and lines[0].strip().lower().startswith(("**panel", "panel ")):
            lines = lines[1:]
        cleaned_text = "\n".join(lines).strip()

        layout.append(
            {
                "panel": idx,
                "title": panel_info.get("title", f"Panel {idx}"),
                "image_path": image,
                "text": cleaned_text,
                "blocks": parse_story_blocks(cleaned_text),
                "scene_description": panel_info.get("scene_description", ""),
            }
        )

    return layout

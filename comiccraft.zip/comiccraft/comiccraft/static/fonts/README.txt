Drop a Unicode TTF font here (e.g. DejaVuSans.ttf) if you want non-Latin character support in exported PDFs. If absent, exporters.py falls back to the built-in Helvetica core font automatically.

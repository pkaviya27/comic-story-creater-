"""
Generates comic-style panel illustrations using Stable Diffusion (Hugging Face Diffusers).
"""

import os
import re
import torch
from diffusers import StableDiffusionPipeline, DPMSolverMultistepScheduler

MODEL_ID = "runwayml/stable-diffusion-v1-5"
device = "cuda" if torch.cuda.is_available() else "cpu"

# Tuned for speed on CPU-only machines. Increase these back up (e.g. 50 steps,
# 512x512) if you have a GPU and want higher-quality output.
NUM_INFERENCE_STEPS = 20
IMAGE_WIDTH = 384
IMAGE_HEIGHT = 384

# Loaded once at import time and reused across requests.
pipe = StableDiffusionPipeline.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.float16 if device == "cuda" else torch.float32,
    use_auth_token=os.getenv("HF_API_KEY"),
)

# DPM-Solver++ reaches good quality in far fewer steps than the default
# scheduler, which is the single biggest speed win on CPU.
pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)

pipe = pipe.to(device)


def sanitize_filename(prompt: str) -> str:
    """Turns a free-text prompt into a safe, short filename."""
    safe = re.sub(r"[^a-zA-Z0-9_\- ]", "", prompt).strip().replace(" ", "_")
    if not safe:
        safe = "panel"
    return f"{safe[:50]}.png"


def generate_image(prompt, filename=None):
    """
    Generates a single comic-style image from a text prompt.

    Args:
        prompt (str): The image prompt to feed to Stable Diffusion.
        filename (str, optional): Custom filename. Auto-generated if omitted.

    Returns:
        str: Path to the saved image (relative to the project root).
    """
    if not filename:
        filename = sanitize_filename(prompt)

    image = pipe(
        prompt,
        num_inference_steps=NUM_INFERENCE_STEPS,
        width=IMAGE_WIDTH,
        height=IMAGE_HEIGHT,
    ).images[0]

    path = f"static/panels/{filename}"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    image.save(path)
    return path

"""
Compiles the finished comic (images + narration) into a downloadable PDF.
"""

import os
from datetime import datetime
from fpdf import FPDF

EXPORT_FOLDER = "static/exports"
# Optional: drop a Unicode TTF font (e.g. DejaVuSans.ttf) here to support
# non-Latin characters / smart quotes in AI-generated text.
FONT_PATH = "static/fonts/DejaVuSans.ttf"

os.makedirs(EXPORT_FOLDER, exist_ok=True)


class PDF(FPDF):
    pass


def _configure_font(pdf: "PDF"):
    """Uses a Unicode TTF font if available, otherwise falls back to a core PDF font."""
    if os.path.exists(FONT_PATH):
        pdf.add_font("DejaVu", "", FONT_PATH, uni=True)
        pdf.set_font("DejaVu", "", 12)
        return "DejaVu"
    else:
        # Core fonts don't need a font file but only support Latin-1.
        pdf.set_font("Helvetica", "", 12)
        return "Helvetica"


def save_pdf(layout):
    """
    Compiles the full comic into a multi-page PDF file.

    Args:
        layout (list[dict]): Output of build_comic_layout(), one dict per panel.

    Returns:
        str: Path to the saved PDF file.
    """
    pdf = PDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    font_name = _configure_font(pdf)

    for panel in layout:
        image_path = panel["image_path"]
        story_text = panel["text"]

        pdf.add_page()

        # Panel title
        pdf.set_font(font_name, "", 14)
        pdf.cell(0, 10, f"Panel {panel['panel']}: {panel.get('title', '')}", ln=True, align="C")
        pdf.set_font(font_name, "", 12)

        # Image placement
        y_image = 30
        image_height = 100
        spacing_after_image = 15

        if os.path.exists(image_path):
            pdf.image(image_path, x=10, y=y_image, w=pdf.w - 20, h=image_height)
        else:
            pdf.set_y(y_image)
            pdf.multi_cell(0, 10, f"Image missing: {image_path}")

        # Text placement below image
        pdf.set_y(y_image + image_height + spacing_after_image)

        # fpdf's core fonts are Latin-1 only; guard against stray Unicode chars.
        safe_text = story_text
        if font_name == "Helvetica":
            safe_text = story_text.encode("latin-1", "replace").decode("latin-1")

        pdf.multi_cell(0, 10, safe_text)

    # Save with timestamp
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filename = f"comic_{timestamp}.pdf"
    pdf_path = os.path.join(EXPORT_FOLDER, filename)
    pdf.output(pdf_path)

    return pdf_path

"""
ComicCraft - AI Comic Story Creator using Gemini Models
Entry point for the FastAPI application.
"""

import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

# Load environment variables from .env (GEMINI_API_KEY, HF_API_KEY) BEFORE
# importing routes, since gemini_flash.py / gemini_pro.py read the keys
# at import time.
load_dotenv()

from app.routes import router  # noqa: E402

app = FastAPI(
    title="ComicCraft",
    description="AI Comic Story Creator using Gemini Models + Stable Diffusion",
    version="1.0.0",
)

# Ensure required static folders exist even on a fresh checkout
os.makedirs("static/panels", exist_ok=True)
os.makedirs("static/exports", exist_ok=True)
os.makedirs("static/fonts", exist_ok=True)

# Serve generated images / exported PDFs
app.mount("/static", StaticFiles(directory="static"), name="static")

# All application routes
app.include_router(router)

"""
Organizes generated images and the full comic story text into a structured
panel-by-panel layout ready for the preview page / PDF exporter.
"""


def build_comic_layout(image_paths, full_story, outline):
    """
    Combines images, story text, and outline metadata into one layout list.

    Args:
        image_paths (list[str]): File paths of the generated panel images, in order.
        full_story (str): The full narration/dialogue text returned by Gemini Pro,
            expected to contain "**Panel N" markers separating each panel.
        outline (list[dict]): The original panel outline from Gemini Flash.

    Returns:
        list[dict]: One dict per panel with keys "panel", "title", "image_path",
            "text", and "scene_description".
    """
    # Split the full story into individual panel segments
    story_panels = full_story.split("**Panel")
    story_panels = [f"**Panel{panel}" for panel in story_panels if panel.strip()]

    # Build layout panel by panel
    layout = []
    for idx, (image, text, panel_info) in enumerate(
        zip(image_paths, story_panels, outline), start=1
    ):
        layout.append(
            {
                "panel": idx,
                "title": panel_info.get("title", f"Panel {idx}"),
                "image_path": image,
                # remove the "**Panel N: Title**" marker line, keep the rest
                "text": "\n".join(text.strip().splitlines()[1:]).strip(),
                "scene_description": panel_info.get("scene_description", ""),
            }
        )

    return layout
